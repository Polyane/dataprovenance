#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "activity.h"

files *used_files = NULL;

activity *define_activity(int *activityNumber, char fileBaseName[N]){ //falta incluir aquivos na lista de arquivos
	activity *original = (activity*)malloc(sizeof(activity));
	
   	time_t t;
	struct tm tm;
    if(!original){
		printf("\nError");
	    exit(1);
	}

	char inputFile1[N], outputFile[N], inputFile2[N], inputFile[N], outputFile1[N], outputFile2[N];
	char command[N] = "";
	switch((*activityNumber)){
		case 1:
			strcpy(command, " ");
			strcpy(inputFile, "ERX412400_1.fastq");
			strcpy(inputFile2, "ERX412400_2.fastq");
		   	strcpy(outputFile, "ERX412400_FILTERED_1.fastq"); 
		   	strcpy(outputFile1, "ERX412400_FILTERED_2.fastq");
		   	strcpy(outputFile2, "ERX412400_SINGLE.fastq");

		   	//strcpy(command, "sickle se --fastq-file SRR5181508.fastq --qual-type sanger --output-file SRR5181508_FILTERED.fastq -q 30 -l 25");
		   	
		   	strcpy(command, "sickle pe -f ERX412400_1.fastq -r ERX412400_2.fastq -t sanger -o ERX412400_FILTERED_1.fastq -p ERX412400_FILTERED_2.fastq -s ERX412400_SINGLE.fastq -q 30 -l 50");

		    printf("\n\t:::::: COMANDO 1 - Workflow bact�ria :::::: \n%s \n", command);
   			printf("::::::");

   			// GET TIME
   			t = time(NULL);
			tm = *localtime(&t);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
			sprintf(original->start_date, "%d-%d-%d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
			sprintf(original->start_hour,"%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);

			system(command);

			//GET TIME
			t = time(NULL);
			tm = *localtime(&t);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
			sprintf(original->end_date, "%d-%d-%d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
			sprintf(original->end_hour,"%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);

			original->id = *activityW2Number;
			printf("\n\n %d", original->id);
			strcpy(original->name, "nome");
			strcpy(original->program_name, sickle);
			strcpy(original->program_version, sickleversion);
			strcpy(original->command_line,command);
			(*activityNumber)++;
		break;
		case 2: 
			strcpy(command, " ");
			strcpy(inputFile, "ERX412400_FILTERED_1.fastq");
			strcpy(inputFile1, "ERX412400_FILTERED_2.fastq");
		   	strcpy(inputFile2, "ERX412400_SINGLE.fastq");

			//abyss-pe np=4 k=31 name=ERX412400_KMER_31 in="ERX412400_FILTERED_1.fastq ERX412400_FILTERED_2.fastq" se='ERX412400_SINGLE.fastq'
			
			strcpy(command, "abyss-pe np=4 k=31 name=ERX412400_KMER_31 in= \"");
		    strcat(command, inputFile);
		    strcat(command, inputFile1);
		    strcat(command, "se= '");
		    strcat(command, outputFile2);
		    strcat(command, "'");

		    printf("\n\t:::::: COMANDO 2- Workflow bact�ria :::::: \n%s \n", command);
   			printf("::::::");

   			// GET TIME
   			t = time(NULL);
			tm = *localtime(&t);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
			sprintf(original->start_date, "%d-%d-%d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
			sprintf(original->start_hour,"%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);

			system(command);

			//GET TIME
			t = time(NULL);
			tm = *localtime(&t);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
			sprintf(original->end_date, "%d-%d-%d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
			sprintf(original->end_hour,"%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);

			original->id = *activityW2Number;
			printf("\n\n %d", original->id);
			strcpy(original->name, "nome");
			strcpy(original->program_name, abyss);
			strcpy(original->program_version, abyssversion);
			strcpy(original->command_line,command);
			//original->execution_status;
			(*activityNumber)++;
			break;
		case 3: 
			strcpy(command, " ");

			strcpy(inputFile, "ERX412400*.fa");
			strcpy(outputFile, "ERX412400_stats");

			strcpy(command, "python /home/biolinux/quast.py -o ERX412400_stats ERX412400*.fa");


		    printf("\n:::::: COMANDO 3 - Workflow bact�ria :::::: \n%s \n", command);
   			printf("::::::");
			//original->id = *activityW2Number;
			//strcpy(original->name, "nome");
			//strcpy(original->program_name, python);
			//strcpy(original->program_version, pythonversion);
			//strcpy(original->command_line,command);

			// GET TIME
   			t = time(NULL);
			tm = *localtime(&t);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
			sprintf(original->start_date, "%d-%d-%d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
			sprintf(original->start_hour,"%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);

			system(command);

			//GET TIME
			t = time(NULL);
			tm = *localtime(&t);
			printf("now: %d-%d-%d %d:%d:%d\n", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
			sprintf(original->end_date, "%d-%d-%d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday);
			sprintf(original->end_hour,"%d:%d:%d", tm.tm_hour, tm.tm_min, tm.tm_sec);

			
			original->id = *activityNumber;
			strcpy(original->name, "nome");
			strcpy(original->program_name, quast);
			strcpy(original->program_version, quastversion);
			strcpy(original->command_line,command);
			(*activityNumber)++;
			break;
		
		default: 
			(*activityNumber)++;
			break;
	}
	return original;
}
// cria o node - não usada
activity *create_activity(){
	activity *new = (activity*)malloc(sizeof(activity));

    if(!new){
		printf("\nError");
	    exit(1);
	}

	printf("Type activity's id: ");
	scanf("%d", &new->id);
	printf("Type activity's name: ");
	scanf("%s", new->name);
	printf("Type activity's program name: ");
	scanf("%s", new->program_name);
	printf("Type activity's program version: "); // pegar a versao
	scanf("%s", new->program_version);
	printf("Type activity's command line: "); // pegar o comando
	scanf("%s", new->command_line);
	printf("Type activity's start_date: ");
	scanf("%s", new->start_date);
	printf("Type activity's start_hour ");
	scanf("%s", new->start_hour);
	printf("Type activity's end_date: ");
	scanf("%s", new->end_date);
	printf("Type activity's end_hour: ");
	scanf("%s", new->end_hour);
	printf("Type activity's execution status: ");
	scanf("%d", &new->execution_status);
	printf("Type activity's experiment id: "); // checar se existe
	scanf("%d", &new->experiment_id);
	/*printf("Type activity's agent id: "); // checar se existe
	scanf("%d", &new->agent_id);*/
	printf("Type activity's machine id: "); // checar se existe
	scanf("%d", &new->machine_id);
	return new;
}

//insere o node
activity *insert_activity(activity *origin, int *activityNumber, char fileBaseName[N]){
	activity *aux = origin;
	//activity *new = create_activity(); //trocar
	
	activity *new = define_activity(activityNumber, fileBaseName); 
	/*if(!existsExperimentId(new->experiment_id, originExp)){
		printf("\nError: There is no experiment with this number");
		return origin;
	}
	if(!existsMachineIdForActivity(new->machine_id, originMac)){
		printf("\nError: There is no machine with this number");
		return origin;
	}*/
	if(aux==NULL){
	    aux = new;
	    new->next = NULL;
	    return new;
	}
	while(aux->next!=NULL){
		aux = aux->next;
	}
	aux->next = new;
	new->next = NULL;
	return origin;
}

void freedom_activity(activity *origin){
    activity *aux1 = origin;
    while(aux1!=NULL){
    	activity *aux2 = aux1->next;
        free(aux1);
        aux1 = aux2;
    }
}

bool existsExperimentId(int expIdExp, experiment *originExp){
 	experiment *aux = originExp;
    while(aux!=NULL){
    	if(expIdExp == aux->id)
    		return true;
       	aux = aux->next;
    }

return false;
}
/*
bool existsAgentId(int expIdAg, agent *originAg){
 	agent *aux = originAg;
    while(aux!=NULL){
    	if(expIdAg == aux->id)
    		return true;
       	aux = aux->next;
    }

return false;
}*/

bool existsMachineIdForActivity(int expIdMac, machine *originMac){
 	machine *aux = originMac;
    while(aux!=NULL){
    	if(expIdMac == aux->id)
    		return true;
       	aux = aux->next;
    }

return false;
}
