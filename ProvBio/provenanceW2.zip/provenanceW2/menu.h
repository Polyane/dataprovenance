#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "activity.h"
#include "agent.h"
#include "cluster.h"
//#include "database.h"
#include "dataFile.h"
#include "experiment.h"
#include "machine.h"
#include "project.h"
#include "provider.h"

#ifndef menu_h
#define menu_h

void mainMenu ();
void secondMenu();

#endif